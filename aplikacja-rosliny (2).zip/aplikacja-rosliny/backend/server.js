const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const cors = require('cors');

// Wczytanie zmiennych środowiskowych z pliku .env
dotenv.config();

// Tworzenie aplikacji Express
const app = express();

// Middleware do obsługi JSON i CORS
app.use(express.json());
app.use(cors());

// Połączenie z MongoDB
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log("✅ Połączono z MongoDB!"))
.catch(err => console.error("❌ Błąd połączenia z MongoDB:", err));

// Import tras API
const authRoutes = require('./routes/authRoutes');
const plantRoutes = require('./routes/plantRoutes');

// Ustawienie tras
app.use('/api/auth', authRoutes);
app.use('/api/plants', plantRoutes);

// Sprawdzenie działania serwera
app.get('/', (req, res) => {
    res.send({ message: "Serwer działa!" });
});

// Uruchomienie serwera
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Serwer działa na porcie ${PORT}`);
});
